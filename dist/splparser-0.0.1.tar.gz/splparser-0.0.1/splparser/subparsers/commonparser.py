#!/urs/bin/env python

from splparser.parsetree import *

# WARNING: The order of the next two rules is important.
def p_fieldlist_field(p):
    """fieldlist : field"""
    p[0] = ParseTreeNode('_FIELDLIST')
    p[0].add_child(p[1])

def p_fieldlist_comma(p):
    """fieldlist : field COMMA fieldlist"""
    p[0] = ParseTreeNode('_FIELDLIST')
    p[0].add_child(p[1])
    p[0].add_children(p[3].children)

def p_fieldlist_space(p):
    """fieldlist : field fieldlist"""
    p[0] = ParseTreeNode('_FIELDLIST')
    p[0].add_child(p[1])
    p[0].add_children(p[2].children)

def p_field_word(p):
    """field : domain"""
    p[0] = p[1]

def p_field_times(p):
    """field : TIMES"""
    p[0] = ParseTreeNode('WILDCARD')

# TODO: Make sure keys can actually be nbstr or if they must be IDs.
def p_field_nbstr(p):
    """field : NBSTR"""
    p[0] = ParseTreeNode('NBSTR', raw=p[1])

## TODO: Think about if other key values can be field names too ...
def p_field_host(p):
    """field : HOST"""
    p[0] = ParseTreeNode('HOST')

def p_field_stats_fn(p):
    """field : statsfnexpr""" # HACK 
    p[0] = ParseTreeNode('WORD', raw=p[1].raw)

def p_as_lc(p):
    """as : ASLC"""
    p[0] = p[1]

def p_as_uc(p):
    """as : ASUC"""
    p[0] = p[1]

def p_by_lc(p):
    """by : BYLC"""
    p[0] = p[1]

def p_by_uc(p):
    """by : BYUC"""
    p[0] = p[1]

def p_value_times(p):
    """value : field"""
    p[0] = p[1]

def p_value_literal(p):
    """value : LITERAL"""
    p[0] = ParseTreeNode('LITERAL', raw=p[1])

def p_value_email(p):
    """value : email"""
    p[0] = p[1]

def p_value_hostname(p):
    """value : hostname"""
    p[0] = p[1]

#def p_value_url(p):
#    """value : url"""
#    p[0] = p[1]

def p_value_ipv6addr(p):
    """value : IPV6ADDR"""
    p[0] = ParseTreeNode('IPV6ADDR', raw=p[1])

def p_value_ipv4addr(p):
    """value : IPV4ADDR"""
    p[0] = ParseTreeNode('IPV4ADDR', raw=p[1])

#def p_value_path(p):
#    """value : path"""
#    p[0] = p[1]

def p_value_bin(p):
    """value : BIN"""
    p[0] = ParseTreeNode('BIN', raw=p[1])

def p_value_oct(p):
    """value : OCT"""
    p[0] = ParseTreeNode('OCT', raw=p[1])

def p_value_hex(p):
    """value : HEX"""
    p[0] = ParseTreeNode('HEX', raw=p[1])

def p_value_int(p):
    """value : INT"""
    p[0] = ParseTreeNode('INT', raw=p[1])

def p_value_float(p):
    """value : FLOAT"""
    p[0] = ParseTreeNode('FLOAT', raw=p[1])

#!/usr/bin/env python

import ply.yacc

from splparser.parsetree import *

def p_cmdexpr_stats(p): # stats-like
    """cmdexpr : statscmd"""
    p[0] = p[1]

def p_stats_statsexprlist(p):
    """statscmd : STATS statsexprlist"""
    p[0] = ParseTreeNode('STATS')
    p[0].add_children(p[2].children)

# WARNING: The order of the next two rules is important.
def p_statsexprlist_statsexpr(p):
    """statsexprlist : statsexpr"""    
    p[0] = ParseTreeNode('_STATSEXPRLIST')
    p[0].add_child(p[1])

def p_statsexprlist_statsexprlist(p):
    """statsexprlist : statsexpr COMMA statsexprlist"""
    p[0] = ParseTreeNode('_STATSEXPRLIST')
    p[0].add_child(p[1])
    p[0].add_children(p[3].children)

def p_statsexpr(p):
    """statsexpr : statsfnexpr"""
    p[0] = p[1]

def p_statsfnexpr_exprfnexpr(p):
    """statsfnexpr : evalfnexpr"""
    p[0] = p[1]

def p_statsexpr_as(p):
    """statsexpr : statsfnexpr as field"""
    as_node = ParseTreeNode('AS')
    as_node.add_child(p[3])
    p[1].add_child(as_node)
    p[0] = p[1]

def p_statsexpr_by(p):
    """statsexpr : statsfnexpr by fieldlist"""
    by_node = ParseTreeNode('BY')
    by_node.add_children(p[3].children)
    p[1].add_child(by_node)
    p[0] = p[1]

def p_statsexpr_as_by(p):
    """statsexpr : statsfnexpr as field by fieldlist""" 
    as_node = ParseTreeNode('AS')
    as_node.add_child(p[3])
    p[1].add_child(as_node)
    by_node = ParseTreeNode('BY')
    by_node.add_children(p[5].children)
    p[1].add_child(by_node)
    p[0] = p[1]

def p_statsfnexpr_parens(p):
    """statsfnexpr : statsfn LPAREN field RPAREN"""
    p[0] = p[1]
    p[0].add_child(p[3])

def p_statsfnexpr(p):
    """statsfnexpr : statsfn"""
    p[0] = p[1]

def p_statsfnexpr_field(p):
    """statsfnexpr : statsfn field"""
    p[0] = p[1]
    p[0].add_child(p[2])

def p_statsfnexpr_statsfn(p):
    """statsfnexpr : statsfn LPAREN statsfnexpr RPAREN"""
    p[0] = p[1]
    p[0].add_child(p[3])

def p_statsfnexpr_keyval(p):
    """statsfnexpr : statsfn LPAREN key EQ value RPAREN"""
    p[0] = p[1]
    eq_node = ParseTreeNode('EQ')
    eq_node.add_children([p[3], p[5]])
    p[0].add_child(eq_node)

def p_statsfn(p):
    """statsfn : STATS_FN"""
    p[0] = ParseTreeNode(p[1].upper())

#def p_statsfn_eval(p):
#    """statsfn : EVAL"""
#    p[0] = ParseTreeNode(p[1].upper())

# TODO: Delete the following after testing the stats command well.
#def p_statsfn_avg(p):
#    """statsfn : AVG"""
#    p[0] = ParseTreeNode('AVG')
#
#def p_statsfn_c(p):
#    """statsfn : C"""
#    p[0] = ParseTreeNode('C')
#
#def p_statsfn_count(p):
#    """statsfn : COUNT"""
#    p[0] = ParseTreeNode('COUNT')
#
#def p_statsfn_dc(p):
#    """statsfn : DC"""
#    p[0] = ParseTreeNode('DC')
#
#def p_statsfn_distinct_count(p):
#    """statsfn : DISTINCT_COUNT"""
#    p[0] = ParseTreeNode('DISTINCT_COUNT')
#
#def p_statsfn_earliest(p):
#    """statsfn : EARLIEST"""
#    p[0] = ParseTreeNode('EARLIEST')
#
#def p_statsfn_estdc(p):
#    """statsfn : ESTDC"""
#    p[0] = ParseTreeNode('ESTDC')
#
#def p_statsfn_estdc_error(p):
#    """statsfn : ESTDC_ERROR"""
#    p[0] = ParseTreeNode('ESTDC_ERROR')
#
#def p_statsfn_first(p):
#    """statsfn : FIRST"""
#    p[0] = ParseTreeNode('FIRST')
#
#def p_statsfn_last(p):
#    """statsfn : LAST"""
#    p[0] = ParseTreeNode('LAST')
#
#def p_statsfn_latest(p):
#    """statsfn : LATEST"""
#    p[0] = ParseTreeNode('LATEST')
#
#def p_statsfn_list(p):
#    """statsfn : LIST"""
#    p[0] = ParseTreeNode('LIST')
#
#def p_statsfn_max(p):
#    """statsfn : MAX"""
#    p[0] = ParseTreeNode('MAX')
#
#def p_statsfn_mean(p):
#    """statsfn : MEAN"""
#    p[0] = ParseTreeNode('MEAN')
#
#def p_statsfn_median(p):
#    """statsfn : MEDIAN"""
#    p[0] = ParseTreeNode('MEDIAN')
#
#def p_statsfn_min(p):
#    """statsfn : MIN"""
#    p[0] = ParseTreeNode('MIN')
#
#def p_statsfn_mode(p):
#    """statsfn : MODE"""
#    p[0] = ParseTreeNode('MODE')
#
#def p_statsfn_per_day(p):
#    """statsfn : PER_DAY"""
#    p[0] = ParseTreeNode('PER_DAY')
#
#def p_statsfn_per_hour(p):
#    """statsfn : PER_HOUR"""
#    p[0] = ParseTreeNode('PER_HOUR')
#
#def p_statsfn_per_minute(p):
#    """statsfn : PER_MINUTE"""
#    p[0] = ParseTreeNode('PER_MINUTE')
#
#def p_statsfn_per_second(p):
#    """statsfn : PER_SECOND"""
#    p[0] = ParseTreeNode('PER_SECOND')
#
#def p_statsfn_range(p):
#    """statsfn : RANGE"""
#    p[0] = ParseTreeNode('RANGE')
#
#def p_statsfn_stdev(p):
#    """statsfn : STDEV"""
#    p[0] = ParseTreeNode('STDEV')
#
#def p_statsfn_stdevp(p):
#    """statsfn : STDEVP"""
#    p[0] = ParseTreeNode('STDEVP')
#
#def p_statsfn_sum(p):
#    """statsfn : SUM"""
#    p[0] = ParseTreeNode('SUM')
#
#def p_statsfn_sumsq(p):
#    """statsfn : SUMSQ"""
#    p[0] = ParseTreeNode('SUMSQ')
#
#def p_statsfn_values(p):
#    """statsfn : VALUES"""
#    p[0] = ParseTreeNode('VALUES')
#
#def p_statsfn_var(p):
#    """statsfn : VAR"""
#    p[0] = ParseTreeNode('VAR')
#
#def p_statsfn_varp(p):
#    """statsfn : VARP"""
#    p[0] = ParseTreeNode('VARP')


def p_by_lc(p):
    """by : BYLC"""
    p[0] = p[1]

def p_by_uc(p):
    """by : BYUC"""
    p[0] = p[1]

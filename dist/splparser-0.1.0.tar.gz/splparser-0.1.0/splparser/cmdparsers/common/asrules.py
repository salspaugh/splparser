
def p_as_lc(p):
    """as : ASLC"""
    p[0] = p[1]

def p_as_uc(p):
    """as : ASUC"""
    p[0] = p[1]


class SPLSyntaxError(SyntaxError):
    
    def __init__(self, message, *args):
        self.message = message
        SyntaxError.__init__(self, message)

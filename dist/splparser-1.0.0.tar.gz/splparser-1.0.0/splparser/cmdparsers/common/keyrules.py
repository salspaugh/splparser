
def p_key_field(p):
    """key : field"""
    p[0] = p[1]
